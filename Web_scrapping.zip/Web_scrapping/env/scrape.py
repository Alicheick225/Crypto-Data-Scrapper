#Importation des modules nécessaires

#Importation du module d'envoi des emails
import send_mail

#Le module requests sert à récupérer les données d'Internet
import requests

#Mon module fav pour afficher les éléments d'une liste en colonne 
from pprint import pprint

#Pour traiter et extraire les données reçus avec le module requests
from bs4 import BeautifulSoup

#Importation du module csv
import csv

#Importation du module date
from datetime import date

#Urls des pages à Scrapper

urls=["https://coinmarketcap.com/currencies/bitcoin/","https://coinmarketcap.com/currencies/mechachain/", "https://coinmarketcap.com/currencies/tron/","https://coinmarketcap.com/currencies/polygon/", "https://coinmarketcap.com/currencies/tether/"]

header={"User_Agent":"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0"}

#Normalement, la méthode get de requests a un paramètre headers qui doit recevoir le header qui contient le user-agent et autres éléments du Header
# Mais dans cet exemple, j'ai volontairement enlevé ce paramètre car je me suis rendu compte que la connexion avec la page en question n'était pas sécurisée et j'ai pas envie de me faire espionner ou voler mes données. 

today=str(date.today())+".csv"

csv_file=open (today, "w", encoding='utf8')
csv_writer=csv.writer(csv_file)
csv_writer.writerow(["Coin Name", "Symbol", "Price", "Marketcap", "Volume", "Volume/Marketcap", "Circulating Supply", "Total Supply", "Max Supply", "Fully diluted Market Cap"])

for url in urls:
    html_page=requests.get(url)

    soup=BeautifulSoup(html_page.content, 'lxml')

    coin_main_info=soup.find(id="section-coin-overview")

    title_coin=coin_main_info.find("h1")

    coin_name=title_coin.find(class_="coin-name-pc").get_text()
    coin_symbol=title_coin.find(class_="coin-symbol-wrapper").get_text()

    coin_price=coin_main_info.find(class_="alignBaseline").find("span").get_text()
    
    data=[]
    data.append(coin_name)
    data.append(coin_symbol)
    data.append(coin_price)


    table_info=soup.find("dl", class_="coin-metrics-table")

    for i in range (0,7):
     data.append(table_info.find_all("dd")[i].get_text())
    
    csv_writer.writerow(data)

csv_file.close()          

send_mail.send(filename=today)